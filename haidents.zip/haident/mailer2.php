<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

if(isset($_POST['phone']))
{
	

	$name=$_POST['name'];
	$phone=$_POST['phone'];
	$message=$_POST['message'];
	$body='
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Document</title>
		<link rel="stylesheet" href="https://incluid.com/ppc-services/assets/css/style.css">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	</head>
	<body style="background-color: white;">
		<div class="col-lg-6 col-sm-6 pt-2 pb-2 bgdg text-center">
		
            <form>
            <div class="mb-3">
			   <p>Name:</p>
              <input type="name" class="form-control" value="'.$name.'"  placeholder="name" name="name">
            </div>
			 <div class="mb-3">
			 <p>Phone:</p>
              <input type="phone" class="form-control" value="'.$phone.'"  placeholder="name" name="phone">
            </div>
          
			  <div class="mb-3">
			<p>Message:</p>
              <input type="message" class="form-control" value="'.$message.'" placeholder="email" name="message">
            </div>
           
             </form>
	</body>
	</html>
	';
	//echo $body;exit;


	

	$mail = new PHPMailer(true);

	try {
		$mail->SMTPDebug = 0;									
		$mail->isSMTP();										
		$mail->Host	 = 'smtp.zoho.in';				
		$mail->SMTPAuth = true;		


		$mail->Username = 'santan@incluid.com';				
		$mail->Password = '@Santan_2023#';					
		$mail->SMTPSecure = 'tls';							
		$mail->Port	 = 587;

		$mail->setFrom('santan@incluid.com', 'haident');	
		$mail->addAddress('santan@incluid.com');
		
         
		$mail->isHTML(true);							 	
		$mail->Subject = 'Hi haident you have new query raised by '.$name;
		$mail->Body = $body;
		$mail->AltBody = '';
		$mail->send();
		//echo "Mail has been sent successfully!";
		header("location:thankyou.html");
	} catch (Exception $e) {
		echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
		header("Refresh:3;url=index.html");
	}
}
else{
	echo '<h1 align="center">Page access not allowed!</center>';
}
	
?>